<footer class="footer footer-black  footer-white ">
    <div class="container-fluid">
        <div class="row">
            <div class="credits ml-auto">
                <span class="copyright">
                    © <script>
                        document.write(new Date().getFullYear())
                    </script>LMS
                </span>
            </div>
        </div>
    </div>
</footer>
</body>
</html>